export const environment = {
  production: false,
  apiBaseUrl: "http://localhost:5000/api",
  ygoApiBase: "https://db.ygoprodeck.com/api/v7",
};
