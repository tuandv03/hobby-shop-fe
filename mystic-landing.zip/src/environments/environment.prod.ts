export const environment = {
  production: true,
  apiBaseUrl: "https://your-backend.example.com/api",
  ygoApiBase: "https://db.ygoprodeck.com/api/v7",
};
