Home page assets placeholder file to ensure directory exists.
